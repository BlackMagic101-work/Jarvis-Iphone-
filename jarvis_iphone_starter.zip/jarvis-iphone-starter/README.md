# JARVIS iPhone Starter (free prototype)

## What this version does
- Phone-friendly JARVIS-style interface
- Text chat with simple built-in commands
- Speech output using browser speech synthesis where available
- Tap-to-talk speech recognition where supported by iOS/Safari
- Local memory notebook stored in this browser using localStorage
- Opens web searches and attempts to open Apple Shortcuts

## Important limitations
This is a starter prototype, not yet a general-purpose AI assistant. It does not have a connected AI model, reliable long-term cloud memory, background wake-word listening, or unrestricted control of the iPhone/computer. Speech recognition support depends on browser/iOS behavior. Never store passwords or sensitive information in the notebook.

## Get it onto your iPhone for free using GitHub Pages
1. On a computer, sign in to GitHub (or create an account if eligible).
2. Create a new **public** repository named `jarvis-iphone`.
3. Upload `index.html` from this folder to the repository root.
4. In the repository, open **Settings → Pages**.
5. Under the build/deployment section, choose deploy from a branch, select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The Pages screen will show the actual URL.
7. On your iPhone, open that URL in **Safari**.
8. Tap **Share → Add to Home Screen**. If shown, enable **Open as Web App**, then tap **Add**.

Do not guess the published URL; use the exact URL shown by GitHub Pages.

## Test it
- Type `help`
- Type `time`
- Tap Search web and enter a topic
- Tap Talk and allow microphone access if prompted
- Save a harmless note in Memory Notebook, reload, and check that it remains

## Next build stages
1. Add a real AI model. Free usage is not guaranteed; many AI APIs require a paid account even if the website/app is free. Never put a secret API key in browser-side HTML.
2. Add explicit, user-approved Shortcuts workflows.
3. Add optional synced memory only after choosing a secure storage approach.
4. Add computer automation from a trusted computer environment, with confirmation before consequential actions.
